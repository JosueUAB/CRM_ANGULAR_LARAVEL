import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-widgets-examples',
  templateUrl: './widgets-examples.component.html',
  styleUrls: ['./widgets-examples.component.scss'],
})
export class WidgetsExamplesComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
