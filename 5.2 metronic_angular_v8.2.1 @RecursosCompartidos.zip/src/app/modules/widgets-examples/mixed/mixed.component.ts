import { Component } from '@angular/core';

@Component({
  selector: 'app-mixed',
  templateUrl: './mixed.component.html',
})
export class MixedComponent {
  constructor() {}
}
