import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feeds',
  templateUrl: './feeds.component.html',
})
export class FeedsComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
