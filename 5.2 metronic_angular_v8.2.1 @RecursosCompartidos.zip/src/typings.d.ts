declare var ClipboardJS: any;
